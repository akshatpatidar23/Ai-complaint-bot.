import { ComplaintData, RiskAssessment, AuditLogItem, SystemNotification } from '../src/types/complaint';
import { DatabaseSchema } from '../src/types/database';

export const initialSeedComplaints: ComplaintData[] = [
  {
    id: 'cmp-001',
    complaintId: 'CMP-2026-0891',
    customerName: 'Apollo Pharmacy',
    complaintDate: '2026-07-25',
    productName: 'Amoxicillin Capsules',
    dosageForm: 'Capsules',
    strength: '500 mg',
    packSize: '10x10 Blister Pack',
    batchNumber: 'BMX24601',
    lotNumber: 'LOT-9012',
    mfgDate: '2025-11-10',
    expiryDate: '2027-11-09',
    defectCategory: 'Physical Defect',
    defectDescription: 'Discolored yellowish spots observed inside transparent capsule shells during receipt inspection at retail branch.',
    complaintCategory: 'Quality Defect',
    quantity: 120,
    unit: 'Capsules',
    packaging: 'Blister Pack',
    country: 'United States',
    plant: 'Plant 1 - Main Facility',
    mfgSite: 'Hyderabad Site Alpha',
    supplier: 'CapsuGel Worldwide Ltd.',
    customerRemarks: 'Stock quarantined on arrival. Customer requested immediate batch investigation and credit replacement.',
    attachments: [
      {
        id: 'att-1',
        name: 'Apollo_Inspection_Report.pdf',
        size: '1.2 MB',
        type: 'application/pdf',
      },
    ],
    priority: 'High',
    status: 'Under Investigation',
    createdAt: '2026-07-25T10:30:00Z',
    updatedAt: '2026-07-25T11:00:00Z',
  },
  {
    id: 'cmp-002',
    complaintId: 'CMP-2026-0892',
    customerName: 'MediCare Regional Hospital',
    complaintDate: '2026-07-26',
    productName: 'Ceftriaxone Injection',
    dosageForm: 'Injectable Powder',
    strength: '1 g',
    packSize: '10 Vials Box',
    batchNumber: 'CFX99104',
    lotNumber: 'LOT-3341',
    mfgDate: '2026-01-15',
    expiryDate: '2028-01-14',
    defectCategory: 'Packaging/Labeling',
    defectDescription: 'Broken flip-off seal and loose rubber stopper detected on 4 vials prior to reconstitution.',
    complaintCategory: 'Packaging Failure',
    quantity: 4,
    unit: 'Vials',
    packaging: 'Glass Vial with Flip-off Seal',
    country: 'United Kingdom',
    plant: 'Plant 2 - Sterile Parenterals',
    mfgSite: 'Wrexham Sterile Unit',
    supplier: 'West Pharmaceutical Services',
    customerRemarks: 'Parenteral sterility compromise concern. Vials isolated in ICU pharmacy.',
    attachments: [
      {
        id: 'att-2',
        name: 'Vial_Seal_Photo.png',
        size: '3.4 MB',
        type: 'image/png',
      },
    ],
    priority: 'Critical',
    status: 'CAPA Initiated',
    createdAt: '2026-07-26T14:15:00Z',
    updatedAt: '2026-07-26T15:20:00Z',
  },
];

class DatabaseService {
  private schema: DatabaseSchema;

  constructor() {
    this.schema = {
      users: [
        {
          id: 'usr-1',
          name: 'Sarah Jenkins',
          email: 's.jenkins@pharmaco.com',
          role: 'Quality Manager',
          department: 'Global Quality Assurance',
        },
        {
          id: 'usr-2',
          name: 'Dr. Aris Thorne',
          email: 'a.thorne@pharmaco.com',
          role: 'QA Investigator',
          department: 'Compliance & CAPA',
        },
      ],
      complaints: [...initialSeedComplaints],
      complaintHistory: [],
      comments: [
        {
          id: 'comm-1',
          complaintId: 'cmp-001',
          userId: 'usr-1',
          userName: 'Sarah Jenkins',
          userRole: 'Quality Manager',
          comment: 'Initiated stability retention sample testing for batch BMX24601.',
          createdAt: '2026-07-25T11:05:00Z',
        },
      ],
      attachments: [],
      auditLogs: [
        {
          id: 'aud-1',
          complaintId: 'cmp-001',
          action: 'COMPLAINT_CREATED',
          performedBy: 'AI Copilot Engine',
          timestamp: '2026-07-25T10:30:00Z',
          details: 'Extracted complaint details from Apollo Pharmacy free text email.',
        },
      ],
      riskAssessments: [
        {
          id: 'ra-1',
          complaintId: 'cmp-001',
          assessment: {
            severity: 'Major',
            riskLevel: 'High',
            impact: 'Discoloration indicates potential moisture degradation or capsule shell reaction.',
            patientRisk: 'Moderate patient exposure risk if potency is diminished or degradation products formed.',
            businessRisk: 'Brand impact with Apollo Pharmacy key retail partner; potential batch quarantine.',
            complianceRisk: 'Requires 15-day FDA Field Alert Report assessment.',
            qualityRisk: 'Blister seal integrity failure during bulk packaging line operations.',
            rootCauseHypothesis: 'Micro-pinholes in foil blister web during sealing station thermal cycle.',
            confidenceScore: 92,
            recommendedNextAction: 'Quarantine distribution stock of BMX24601 and test retain samples.',
            escalation: true,
            escalationDetails: 'Escalated to Site Quality Head and Packaging Line Manager.',
            capaRecommendation: 'Inspect packaging line 4 heat seal temperature sensors and foil feeder.',
            replacementRecommendation: 'Issue immediate replacement credit note for 120 capsules.',
            recallRecommendation: 'Batch recall not required yet; pending retain sample assay testing.',
            qaInvestigation: 'Perform HPLC chemical assay and moisture content test on retain samples.',
            regulatoryReportingRecommendation: 'Submit 15-Day FAR report if moisture degradation confirmed.',
            reasoningSummary: 'Discoloration on oral solids suggests environmental moisture ingress. Severity rated Major due to commercial distribution state.',
          },
          createdAt: '2026-07-25T10:30:00Z',
        },
      ],
      aiConversations: [],
      documentMetadata: [],
      notifications: [
        {
          id: 'notif-1',
          title: 'Critical Risk Alert',
          message: 'Ceftriaxone Injection CMP-2026-0892 flagged Critical severity due to parenteral sterility defect.',
          type: 'risk',
          timestamp: '2026-07-26T14:16:00Z',
          read: false,
          complaintId: 'cmp-002',
        },
      ],
    };
  }

  public getComplaints(): ComplaintData[] {
    return this.schema.complaints;
  }

  public getComplaintById(id: string): ComplaintData | undefined {
    return this.schema.complaints.find((c) => c.id === id || c.complaintId === id);
  }

  public saveComplaint(complaintData: Partial<ComplaintData>, modifiedBy = 'AI Copilot'): { complaint: ComplaintData; isNew: boolean } {
    const existingIndex = this.schema.complaints.findIndex(
      (c) => c.id === complaintData.id || (complaintData.complaintId && c.complaintId === complaintData.complaintId)
    );

    const now = new Date().toISOString();

    if (existingIndex >= 0) {
      const current = this.schema.complaints[existingIndex];
      const updated: ComplaintData = {
        ...current,
        ...complaintData,
        updatedAt: now,
      };

      // Add to history
      const versionNumber = this.schema.complaintHistory.filter((h) => h.complaintId === current.id).length + 1;
      this.schema.complaintHistory.push({
        id: `hist-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        complaintId: current.id,
        version: versionNumber,
        snapshot: JSON.parse(JSON.stringify(current)),
        modifiedBy,
        modifiedAt: now,
        reason: 'Updated via AI Copilot or user editing',
      });

      this.schema.complaints[existingIndex] = updated;

      this.addAuditLog({
        complaintId: updated.id,
        action: 'COMPLAINT_UPDATED',
        performedBy: modifiedBy,
        details: `Updated complaint ${updated.complaintId} details via AI Copilot.`,
      });

      return { complaint: updated, isNew: false };
    } else {
      const newId = complaintData.id || `cmp-${Date.now()}`;
      const complaintId = complaintData.complaintId || `CMP-2026-${Math.floor(1000 + Math.random() * 9000)}`;

      const newComplaint: ComplaintData = {
        id: newId,
        complaintId,
        customerName: complaintData.customerName || 'Unspecified Customer',
        complaintDate: complaintData.complaintDate || now.split('T')[0],
        productName: complaintData.productName || '',
        dosageForm: complaintData.dosageForm || 'Capsules',
        strength: complaintData.strength || '',
        packSize: complaintData.packSize || '',
        batchNumber: complaintData.batchNumber || '',
        lotNumber: complaintData.lotNumber || '',
        mfgDate: complaintData.mfgDate || '',
        expiryDate: complaintData.expiryDate || '',
        defectCategory: complaintData.defectCategory || 'Physical Defect',
        defectDescription: complaintDescriptionFormat(complaintData.defectDescription),
        complaintCategory: complaintData.complaintCategory || 'Quality Defect',
        quantity: complaintData.quantity ?? null,
        unit: complaintData.unit || 'Units',
        packaging: complaintData.packaging || '',
        country: complaintData.country || 'Global',
        plant: complaintData.plant || 'Plant 1',
        mfgSite: complaintData.mfgSite || 'Primary Manufacturing Site',
        supplier: complaintData.supplier || '',
        customerRemarks: complaintData.customerRemarks || '',
        attachments: complaintData.attachments || [],
        priority: complaintData.priority || 'Medium',
        status: complaintData.status || 'Draft',
        createdAt: now,
        updatedAt: now,
      };

      this.schema.complaints.unshift(newComplaint);

      this.addAuditLog({
        complaintId: newComplaint.id,
        action: 'COMPLAINT_CREATED',
        performedBy: modifiedBy,
        details: `Created new complaint ${newComplaint.complaintId} for ${newComplaint.customerName}.`,
      });

      return { complaint: newComplaint, isNew: true };
    }
  }

  public saveRiskAssessment(complaintId: string, assessment: RiskAssessment) {
    const id = `ra-${Date.now()}`;
    this.schema.riskAssessments.push({
      id,
      complaintId,
      assessment,
      createdAt: new Date().toISOString(),
    });

    if (assessment.severity === 'Critical' || assessment.escalation) {
      this.addNotification({
        title: `${assessment.severity.toUpperCase()} Risk Alert`,
        message: `Complaint ${complaintId} requires immediate QA escalation: ${assessment.recommendedNextAction}`,
        type: 'escalation',
        complaintId,
      });
    }
  }

  public getLatestRiskAssessment(complaintId: string): RiskAssessment | undefined {
    const list = this.schema.riskAssessments.filter((r) => r.complaintId === complaintId);
    if (list.length === 0) return undefined;
    return list[list.length - 1].assessment;
  }

  public findDuplicates(productName: string, batchNumber: string, defectDesc: string): { isDuplicate: boolean; existingComplaintId?: string; similarityReason?: string } {
    if (!productName || !batchNumber) return { isDuplicate: false };

    const normProd = productName.toLowerCase().trim();
    const normBatch = batchNumber.toLowerCase().trim();

    const match = this.schema.complaints.find(
      (c) => c.productName.toLowerCase().trim() === normProd && c.batchNumber.toLowerCase().trim() === normBatch
    );

    if (match) {
      return {
        isDuplicate: true,
        existingComplaintId: match.complaintId,
        similarityReason: `Identical product (${match.productName}) and batch number (${match.batchNumber}) already registered under complaint ${match.complaintId}.`,
      };
    }

    return { isDuplicate: false };
  }

  public getComplaintHistory(complaintId: string) {
    return this.schema.complaintHistory.filter((h) => h.complaintId === complaintId);
  }

  public getAuditLogs() {
    return this.schema.auditLogs;
  }

  public addAuditLog(item: Omit<AuditLogItem, 'id' | 'timestamp'>) {
    this.schema.auditLogs.unshift({
      ...item,
      id: `aud-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toISOString(),
    });
  }

  public getNotifications() {
    return this.schema.notifications;
  }

  public addNotification(notif: Omit<SystemNotification, 'id' | 'timestamp' | 'read'>) {
    this.schema.notifications.unshift({
      ...notif,
      id: `notif-${Date.now()}`,
      timestamp: new Date().toISOString(),
      read: false,
    });
  }

  public addComment(complaintId: string, userId: string, userName: string, userRole: string, comment: string) {
    const newComment = {
      id: `comm-${Date.now()}`,
      complaintId,
      userId,
      userName,
      userRole,
      comment,
      createdAt: new Date().toISOString(),
    };
    this.schema.comments.push(newComment);
    return newComment;
  }

  public getComments(complaintId: string) {
    return this.schema.comments.filter((c) => c.complaintId === complaintId);
  }

  public getFullSchemaDump() {
    return this.schema;
  }

  public resetToSeed() {
    this.schema.complaints = [...initialSeedComplaints];
    this.schema.auditLogs = [];
    this.schema.riskAssessments = [];
    return { success: true, count: this.schema.complaints.length };
  }
}

function complaintDescriptionFormat(desc?: string): string {
  if (!desc) return '';
  return desc.trim();
}

export const db = new DatabaseService();
