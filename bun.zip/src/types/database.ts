import { ComplaintData, RiskAssessment, AuditLogItem, SystemNotification } from './complaint';

export interface DatabaseSchema {
  users: Array<{
    id: string;
    name: string;
    email: string;
    role: string;
    department: string;
  }>;
  complaints: ComplaintData[];
  complaintHistory: Array<{
    id: string;
    complaintId: string;
    version: number;
    snapshot: ComplaintData;
    modifiedBy: string;
    modifiedAt: string;
    reason: string;
  }>;
  comments: Array<{
    id: string;
    complaintId: string;
    userId: string;
    userName: string;
    userRole: string;
    comment: string;
    createdAt: string;
  }>;
  attachments: Array<{
    id: string;
    complaintId: string;
    fileName: string;
    fileType: string;
    fileSize: number;
    extractedText?: string;
    uploadedAt: string;
  }>;
  auditLogs: AuditLogItem[];
  riskAssessments: Array<{
    id: string;
    complaintId: string;
    assessment: RiskAssessment;
    createdAt: string;
  }>;
  aiConversations: Array<{
    id: string;
    complaintId: string;
    sessionId: string;
    messages: any[];
    createdAt: string;
  }>;
  documentMetadata: Array<{
    id: string;
    fileName: string;
    fileType: string;
    ocrStatus: 'Success' | 'Partial' | 'Failed';
    extractedFieldsCount: number;
    confidenceScore: number;
    createdAt: string;
  }>;
  notifications: SystemNotification[];
}
