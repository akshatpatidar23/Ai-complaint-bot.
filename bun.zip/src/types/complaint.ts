export type PriorityLevel = 'Low' | 'Medium' | 'High' | 'Critical';
export type ComplaintStatus = 'Draft' | 'Submitted' | 'Under Investigation' | 'CAPA Initiated' | 'Closed';

export type DefectCategory = 
  | 'Physical Defect'
  | 'Chemical/Potency'
  | 'Packaging/Labeling'
  | 'Microbial/Contamination'
  | 'Foreign Matter'
  | 'Storage/Temperature'
  | 'Other';

export type ComplaintCategory = 
  | 'Quality Defect'
  | 'Adverse Event'
  | 'Supply Chain Issue'
  | 'Packaging Failure'
  | 'Customer Inquiry';

export interface AttachmentItem {
  id: string;
  name: string;
  size: string;
  type: string;
  url?: string;
  extractedText?: string;
}

export interface ComplaintData {
  id: string;
  complaintId: string;
  customerName: string;
  complaintDate: string;
  productName: string;
  dosageForm: string;
  strength: string;
  packSize: string;
  batchNumber: string;
  lotNumber: string;
  mfgDate: string;
  expiryDate: string;
  defectCategory: DefectCategory | string;
  defectDescription: string;
  complaintCategory: ComplaintCategory | string;
  quantity: number | null;
  unit: string;
  packaging: string;
  country: string;
  plant: string;
  mfgSite: string;
  supplier: string;
  customerRemarks: string;
  attachments: AttachmentItem[];
  priority: PriorityLevel;
  status: ComplaintStatus;
  createdAt?: string;
  updatedAt?: string;
}

export interface RiskAssessment {
  severity: 'Critical' | 'Major' | 'Minor';
  riskLevel: 'Extreme' | 'High' | 'Medium' | 'Low';
  impact: string;
  patientRisk: string;
  businessRisk: string;
  complianceRisk: string;
  qualityRisk: string;
  rootCauseHypothesis: string;
  confidenceScore: number; // 0 to 100
  recommendedNextAction: string;
  escalation: boolean;
  escalationDetails?: string;
  capaRecommendation: string;
  replacementRecommendation: string;
  recallRecommendation: string;
  qaInvestigation: string;
  regulatoryReportingRecommendation: string;
  reasoningSummary: string;
}

export interface FieldDiff {
  field: keyof ComplaintData;
  label: string;
  oldValue: any;
  newValue: any;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  extractedJSON?: Partial<ComplaintData>;
  riskAssessment?: RiskAssessment;
  diffs?: FieldDiff[];
  isDocumentExtract?: boolean;
  fileName?: string;
  missingFields?: string[];
  duplicateWarning?: {
    isDuplicate: boolean;
    existingComplaintId?: string;
    similarityReason?: string;
  };
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'Quality Manager' | 'QA Investigator' | 'Compliance Specialist' | 'Admin';
  avatar: string;
}

export interface AuditLogItem {
  id: string;
  complaintId: string;
  action: string;
  performedBy: string;
  timestamp: string;
  details: string;
  changedFields?: FieldDiff[];
}

export interface SystemNotification {
  id: string;
  title: string;
  message: string;
  type: 'risk' | 'escalation' | 'capa' | 'info';
  timestamp: string;
  read: boolean;
  complaintId?: string;
}
