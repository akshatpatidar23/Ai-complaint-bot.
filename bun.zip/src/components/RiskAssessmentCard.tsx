import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  CheckCircle,
  Activity,
  FileCheck2,
  ChevronDown,
  ChevronUp,
  Brain,
  Zap,
  ArrowUpRight,
  TrendingUp,
  Scale,
  Building,
  User,
  FlaskConical,
  ClipboardList,
} from 'lucide-react';
import { RiskAssessment } from '../types/complaint';

interface RiskAssessmentCardProps {
  risk: RiskAssessment;
}

export const RiskAssessmentCard: React.FC<RiskAssessmentCardProps> = ({ risk }) => {
  const [showReasoning, setShowReasoning] = useState(false);

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'Critical':
        return 'bg-rose-500 text-white font-bold shadow-sm shadow-rose-500/30';
      case 'Major':
        return 'bg-amber-500 text-white font-bold shadow-sm shadow-amber-500/30';
      default:
        return 'bg-blue-500 text-white font-bold shadow-sm shadow-blue-500/30';
    }
  };

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'Extreme':
      case 'High':
        return 'text-rose-600 dark:text-rose-400 border-rose-500/30 bg-rose-500/10';
      case 'Medium':
        return 'text-amber-600 dark:text-amber-400 border-amber-500/30 bg-amber-500/10';
      default:
        return 'text-emerald-600 dark:text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl text-slate-100 space-y-4 my-2 overflow-hidden">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-indigo-500/20 text-indigo-400 rounded-lg border border-indigo-500/30">
            <Brain className="h-4 w-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              AI Quality Risk Assessment
            </h4>
            <p className="text-[10px] text-slate-400">cGMP & Risk Engine Evaluation</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className={`px-2.5 py-0.5 rounded-full text-xs uppercase tracking-wider ${getSeverityBadge(risk.severity)}`}>
            {risk.severity} Severity
          </span>
          <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getRiskLevelColor(risk.riskLevel)}`}>
            {risk.riskLevel} Risk Level
          </span>
        </div>
      </div>

      {/* Confidence & Recommended Action Alert */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Confidence Dial */}
        <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 flex items-center gap-3">
          <div className="relative h-12 w-12 flex items-center justify-center shrink-0">
            <svg className="h-12 w-12 transform -rotate-90">
              <circle cx="24" cy="24" r="20" stroke="currentColor" strokeWidth="4" className="text-slate-800" fill="transparent" />
              <circle
                cx="24"
                cy="24"
                r="20"
                stroke="currentColor"
                strokeWidth="4"
                className="text-indigo-400 transition-all duration-1000"
                strokeDasharray={125}
                strokeDashoffset={125 - (125 * (risk.confidenceScore || 90)) / 100}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>
            <span className="absolute text-xs font-extrabold text-indigo-300 font-mono">
              {risk.confidenceScore}%
            </span>
          </div>
          <div>
            <div className="text-[10px] uppercase font-semibold text-slate-400">
              AI Confidence
            </div>
            <div className="text-xs font-medium text-slate-200">
              {risk.confidenceScore > 85 ? 'High Precision' : 'Moderate Precision'}
            </div>
          </div>
        </div>

        {/* Immediate Next Action */}
        <div className="sm:col-span-2 bg-indigo-950/40 p-3 rounded-xl border border-indigo-900/60 flex items-start gap-2.5">
          <Zap className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <div className="text-[10px] uppercase font-bold text-indigo-300 tracking-wider">
              Recommended Immediate Action
            </div>
            <p className="text-xs font-semibold text-slate-100 leading-snug">
              {risk.recommendedNextAction}
            </p>
          </div>
        </div>
      </div>

      {/* Impact Breakdown Matrix */}
      <div className="space-y-2">
        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <Activity className="h-3.5 w-3.5 text-sky-400" />
          Risk Impact Matrix
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          {/* Patient Risk */}
          <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-rose-400 text-[11px]">
              <User className="h-3.5 w-3.5" /> Patient Risk
            </div>
            <p className="text-[11px] text-slate-300 leading-normal">{risk.patientRisk}</p>
          </div>

          {/* Compliance Risk */}
          <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-amber-400 text-[11px]">
              <Scale className="h-3.5 w-3.5" /> Compliance & Regulatory Risk
            </div>
            <p className="text-[11px] text-slate-300 leading-normal">{risk.complianceRisk}</p>
          </div>

          {/* Business Risk */}
          <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-purple-400 text-[11px]">
              <Building className="h-3.5 w-3.5" /> Business & Commercial Risk
            </div>
            <p className="text-[11px] text-slate-300 leading-normal">{risk.businessRisk}</p>
          </div>

          {/* Quality Risk */}
          <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-sky-400 text-[11px]">
              <FlaskConical className="h-3.5 w-3.5" /> Manufacturing Quality Risk
            </div>
            <p className="text-[11px] text-slate-300 leading-normal">{risk.qualityRisk}</p>
          </div>
        </div>
      </div>

      {/* Scientific Root Cause Hypothesis */}
      <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1">
        <div className="text-[11px] font-bold uppercase text-indigo-400 flex items-center gap-1.5">
          <FlaskConical className="h-3.5 w-3.5" /> Root Cause Hypothesis
        </div>
        <p className="text-xs text-slate-200 leading-relaxed font-mono">
          {risk.rootCauseHypothesis}
        </p>
      </div>

      {/* Action Plan Grid: CAPA, Replacement, Recall, Regulatory */}
      <div className="space-y-2 pt-1">
        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <ClipboardList className="h-3.5 w-3.5 text-emerald-400" />
          Mandatory Quality Action Recommendations
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
          <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
            <span className="font-bold text-slate-300">CAPA Plan:</span> {risk.capaRecommendation}
          </div>
          <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
            <span className="font-bold text-slate-300">Replacement:</span> {risk.replacementRecommendation}
          </div>
          <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
            <span className="font-bold text-slate-300">Market Recall:</span> {risk.recallRecommendation}
          </div>
          <div className="bg-slate-950/60 p-2 rounded-lg border border-slate-800">
            <span className="font-bold text-slate-300">Regulatory Reporting:</span> {risk.regulatoryReportingRecommendation}
          </div>
        </div>
      </div>

      {/* Escalation details if applicable */}
      {risk.escalation && (
        <div className="bg-rose-950/50 p-2.5 rounded-xl border border-rose-800/80 text-xs text-rose-200 flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-rose-400 shrink-0" />
          <span>
            <strong>QA Escalation Flagged:</strong> {risk.escalationDetails || 'Escalated to Site Quality Head and CAPA Committee.'}
          </span>
        </div>
      )}

      {/* Reasoning Summary Accordion */}
      <div className="pt-2 border-t border-slate-800">
        <button
          onClick={() => setShowReasoning(!showReasoning)}
          className="flex items-center justify-between w-full text-xs font-semibold text-slate-400 hover:text-slate-200 transition-colors"
        >
          <span className="flex items-center gap-1.5">
            <Brain className="h-3.5 w-3.5 text-indigo-400" />
            AI Rationale & Regulatory Reasoning Summary
          </span>
          {showReasoning ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>

        {showReasoning && (
          <div className="mt-2 p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300 leading-relaxed space-y-2">
            <p>{risk.reasoningSummary}</p>
            <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-800">
              Evaluated against FDA 21 CFR 211.198 (Customer Complaint Records), EU GMP Chapter 8, and ICH Q9 Quality Risk Management principles.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
