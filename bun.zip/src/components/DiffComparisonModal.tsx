import React from 'react';
import { X, History, ArrowRight, CheckCircle2, Sparkles } from 'lucide-react';
import { FieldDiff } from '../types/complaint';

interface DiffComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
  diffs: FieldDiff[];
  complaintId?: string;
}

export const DiffComparisonModal: React.FC<DiffComparisonModalProps> = ({
  isOpen,
  onClose,
  diffs,
  complaintId,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Modal Header */}
        <div className="bg-slate-900 text-slate-100 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/30">
              <History className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                AI Edit Field Comparison (Before vs After)
              </h3>
              <p className="text-xs text-slate-400">
                Tracked field modifications for complaint <span className="font-mono text-indigo-300">{complaintId || 'Record'}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4 text-xs">
          {diffs.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              No recent field modifications detected in this session. Try asking the AI to update a field in chat (e.g., <em>"Update batch number to BMX24602"</em>).
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-semibold text-xs">
                <Sparkles className="h-4 w-4" />
                {diffs.length} Field{diffs.length > 1 ? 's' : ''} Updated via Natural Language Request:
              </div>

              <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[11px] uppercase tracking-wider font-bold">
                      <th className="p-3 border-b border-slate-200 dark:border-slate-700">Field Name</th>
                      <th className="p-3 border-b border-slate-200 dark:border-slate-700">Original Value (Before)</th>
                      <th className="p-3 border-b border-slate-200 dark:border-slate-700">Updated Value (After)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                    {diffs.map((d, index) => (
                      <tr key={index} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                        <td className="p-3 font-semibold text-slate-900 dark:text-slate-100">
                          {d.label}
                        </td>
                        <td className="p-3 text-rose-600 dark:text-rose-400 font-mono bg-rose-500/5 line-through">
                          {String(d.oldValue ?? '(Empty)')}
                        </td>
                        <td className="p-3 text-emerald-600 dark:text-emerald-400 font-mono font-bold bg-emerald-500/5">
                          <div className="flex items-center gap-1.5">
                            <ArrowRight className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
                            <span>{String(d.newValue ?? '(Empty)')}</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 dark:bg-slate-950 px-6 py-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-xs transition-colors shadow-sm"
          >
            Acknowledge Changes
          </button>
        </div>
      </div>
    </div>
  );
};
