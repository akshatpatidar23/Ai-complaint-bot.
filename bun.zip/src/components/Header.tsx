import React from 'react';
import { Bot, Database, FolderOpen, RefreshCw, FileText, ShieldAlert, UserCheck, Sparkles } from 'lucide-react';
import { UserProfile } from '../types/complaint';

interface HeaderProps {
  user: UserProfile;
  onOpenDirectory: () => void;
  onOpenDbInspector: () => void;
  onOpenArchitecture: () => void;
  onResetData: () => void;
  activeComplaintId?: string;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  onOpenDirectory,
  onOpenDbInspector,
  onOpenArchitecture,
  onResetData,
  activeComplaintId,
}) => {
  return (
    <header className="h-14 bg-slate-900 border-b border-slate-800 text-slate-100 px-4 sm:px-6 flex items-center justify-between flex-shrink-0 z-30">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-md shadow-blue-600/30">
          C
        </div>
        <h1 className="text-base sm:text-lg font-semibold tracking-tight text-slate-100 flex items-center gap-2">
          Complaint <span className="text-blue-400 font-mono italic text-xs sm:text-sm">Copilot v2.4</span>
        </h1>
      </div>

      <div className="flex items-center gap-3 sm:gap-5 text-xs">
        <div className="hidden md:flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="uppercase tracking-widest text-slate-400 font-bold text-[10px]">
            AI System Online
          </span>
        </div>

        {activeComplaintId && (
          <div className="hidden sm:flex items-center gap-2 border-l border-slate-800 pl-4">
            <span className="text-slate-400 font-medium uppercase text-[10px]">Active Case:</span>
            <span className="font-mono bg-slate-800 px-2 py-0.5 rounded text-blue-300 text-xs border border-slate-700">
              {activeComplaintId}
            </span>
          </div>
        )}

        <div className="h-4 w-px bg-slate-800 hidden sm:block" />

        {/* Action Tool Buttons */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onOpenDirectory}
            id="btn-open-directory"
            className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
            title="Browse complaints directory"
          >
            <FolderOpen className="h-3.5 w-3.5 text-sky-400" />
            <span className="hidden md:inline">Directory</span>
          </button>

          <button
            onClick={onOpenDbInspector}
            id="btn-open-db-inspector"
            className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
            title="Inspect relational database schema"
          >
            <Database className="h-3.5 w-3.5 text-purple-400" />
            <span className="hidden md:inline">DB Inspector</span>
          </button>

          <button
            onClick={onOpenArchitecture}
            id="btn-open-architecture"
            className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
            title="Architecture & API docs"
          >
            <FileText className="h-3.5 w-3.5 text-amber-400" />
            <span className="hidden md:inline">Docs</span>
          </button>

          <button
            onClick={onResetData}
            id="btn-reset-data"
            className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
            title="Reset dataset"
          >
            <RefreshCw className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="h-4 w-px bg-slate-800 hidden sm:block" />

        {/* User Profile */}
        <div className="flex items-center gap-2">
          <img
            src={user.avatar}
            alt={user.name}
            className="h-7 w-7 rounded-lg border border-slate-700 object-cover"
          />
          <div className="hidden lg:block text-left">
            <div className="text-[11px] font-bold text-slate-200 leading-none">{user.name}</div>
            <div className="text-[9px] text-blue-400 uppercase font-semibold">{user.role}</div>
          </div>
        </div>
      </div>
    </header>
  );
};
