import React from 'react';
import {
  Lock,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Package,
  Building2,
  FileCheck,
  Tag,
  Hash,
  AlertCircle,
  FileText,
  MapPin,
  Clock,
  History,
  Paperclip,
  Check,
  Printer,
  Shield,
  Send,
} from 'lucide-react';
import { ComplaintData, FieldDiff } from '../types/complaint';

interface ComplaintFormPanelProps {
  formData: ComplaintData;
  diffs?: FieldDiff[];
  onOpenDiffModal: () => void;
  onSaveComplaint: () => void;
  onGenerateReport: () => void;
  isSaved?: boolean;
}

export const ComplaintFormPanel: React.FC<ComplaintFormPanelProps> = ({
  formData,
  diffs = [],
  onOpenDiffModal,
  onSaveComplaint,
  onGenerateReport,
  isSaved = false,
}) => {
  // Identify missing fields for validation banner
  const missingFields: string[] = [];
  if (!formData.customerName || formData.customerName === 'Unspecified Customer') missingFields.push('Customer Name');
  if (!formData.productName) missingFields.push('Product Name');
  if (!formData.batchNumber) missingFields.push('Batch Number');
  if (!formData.defectDescription) missingFields.push('Defect Description');
  if (!formData.expiryDate) missingFields.push('Expiry Date');

  // Helper to check if a field was changed in recent AI turn
  const isFieldChanged = (fieldKey: keyof ComplaintData) => {
    return diffs.some((d) => d.field === fieldKey);
  };

  const getPriorityBadge = (priority?: string) => {
    switch (priority) {
      case 'Critical':
        return 'bg-rose-500/10 text-rose-700 dark:text-rose-400 border-rose-200 dark:border-rose-900/50';
      case 'High':
        return 'bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-900/50';
      case 'Medium':
        return 'bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-200 dark:border-blue-900/50';
      default:
        return 'bg-slate-500/10 text-slate-700 dark:text-slate-400 border-slate-200 dark:border-slate-800';
    }
  };

  const getStatusBadge = (status?: string) => {
    switch (status) {
      case 'Closed':
        return 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/50';
      case 'CAPA Initiated':
        return 'bg-purple-500/10 text-purple-700 dark:text-purple-400 border-purple-200 dark:border-purple-900/50';
      case 'Under Investigation':
        return 'bg-sky-500/10 text-sky-700 dark:text-sky-400 border-sky-200 dark:border-sky-900/50';
      default:
        return 'bg-slate-500/10 text-slate-700 dark:text-slate-400 border-slate-200 dark:border-slate-800';
    }
  };

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-xl shadow-lg overflow-hidden flex flex-col h-full">
      {/* Panel Header */}
      <div className="p-3.5 px-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 bg-slate-900/60 shrink-0">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-blue-600/20 text-blue-400 rounded-lg border border-blue-500/30">
            <FileCheck className="h-4 w-4" />
          </div>
          <div>
            <h2 className="text-xs font-black uppercase tracking-widest text-slate-300 flex items-center gap-2">
              Structured Case Data
              <span className="text-[10px] text-emerald-400 border border-emerald-400/30 px-2 py-0.5 rounded bg-emerald-400/10 font-mono font-normal">
                Synced with AI
              </span>
            </h2>
          </div>
        </div>

        {/* Actions & Status */}
        <div className="flex items-center gap-2">
          {diffs.length > 0 && (
            <button
              onClick={onOpenDiffModal}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-blue-300 bg-blue-900/30 border border-blue-500/40 rounded hover:bg-blue-900/50 transition-colors animate-pulse"
            >
              <History className="h-3 w-3" />
              <span>AI Edit Diff ({diffs.length})</span>
            </button>
          )}

          <button
            onClick={onGenerateReport}
            id="btn-generate-report"
            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
            title="Download formatted cGMP / FDA report"
          >
            <Printer className="h-3 w-3 text-slate-400" />
            <span className="hidden sm:inline">Export</span>
          </button>

          <button
            onClick={onSaveComplaint}
            id="btn-save-complaint"
            className={`inline-flex items-center gap-1 px-3 py-1 text-[11px] font-bold rounded transition-all shadow-sm ${
              isSaved
                ? 'bg-emerald-600 text-white'
                : 'bg-blue-600 hover:bg-blue-500 text-white'
            }`}
          >
            {isSaved ? (
              <>
                <Check className="h-3 w-3" /> Saved
              </>
            ) : (
              <>
                <Send className="h-3 w-3" /> Finalize Case
              </>
            )}
          </button>
        </div>
      </div>

      {/* Validation Warnings if any missing critical fields */}
      {missingFields.length > 0 && (
        <div className="bg-rose-950/40 border-b border-rose-500/30 px-4 py-1.5 text-xs text-rose-300 flex items-center justify-between gap-2 flex-wrap shrink-0">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-3.5 w-3.5 text-rose-400 shrink-0" />
            <span>
              <strong className="uppercase text-[10px] tracking-wider">Validation Alert:</strong> Missing: {missingFields.join(', ')}.
            </span>
          </div>
          <span className="text-[10px] text-rose-400 font-medium">
            Provide details in AI Chat
          </span>
        </div>
      )}

      {/* Main Form Fields Content - High Density Grid */}
      <div className="p-4 overflow-y-auto space-y-4 flex-1 text-slate-200">
        {/* Case Reference Header Bar */}
        <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-lg flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Hash className="h-4 w-4 text-blue-400" />
            <span className="text-[10px] uppercase font-bold text-slate-500">Case Ref:</span>
            <span className="font-mono font-bold text-sm text-blue-300">{formData.complaintId || 'CMP-2026-AUTO'}</span>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${getPriorityBadge(formData.priority)}`}>
              {formData.priority || 'Medium'}
            </span>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${getStatusBadge(formData.status)}`}>
              {formData.status || 'Draft'}
            </span>
          </div>
        </div>

        {/* SECTION 1: Customer & Incident Metadata */}
        <div className="space-y-2">
          <div className="border-b border-slate-800 pb-1">
            <h3 className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">Customer & Logistics</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <FieldWrapper label="Customer Name" isChanged={isFieldChanged('customerName')}>
              <div className="bg-slate-900 border border-slate-800 p-2 text-xs text-slate-200 rounded font-semibold truncate">
                {formData.customerName || 'N/A'}
              </div>
            </FieldWrapper>

            <FieldWrapper label="Complaint Date" isChanged={isFieldChanged('complaintDate')}>
              <div className="bg-slate-900 border border-slate-800 p-2 text-xs font-mono text-slate-300 rounded">
                {formData.complaintDate || 'N/A'}
              </div>
            </FieldWrapper>

            <FieldWrapper label="Country" isChanged={isFieldChanged('country')}>
              <div className="bg-slate-900 border border-slate-800 p-2 text-xs text-slate-300 rounded">
                {formData.country || 'N/A'}
              </div>
            </FieldWrapper>
          </div>
        </div>

        {/* SECTION 2: Product Specifications */}
        <div className="space-y-2">
          <div className="border-b border-slate-800 pb-1 mt-2">
            <h3 className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">Product & Batch Metadata</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <FieldWrapper label="Product Name" isChanged={isFieldChanged('productName')}>
              <div className="bg-slate-900 border border-slate-800 p-2 text-xs text-slate-200 font-bold rounded truncate">
                {formData.productName || 'N/A'}
              </div>
            </FieldWrapper>

            <FieldWrapper label="Dosage Form" isChanged={isFieldChanged('dosageForm')}>
              <div className="bg-slate-900 border border-slate-800 p-2 text-xs text-slate-300 rounded">
                {formData.dosageForm || 'N/A'}
              </div>
            </FieldWrapper>

            <FieldWrapper label="Strength" isChanged={isFieldChanged('strength')}>
              <div className="bg-slate-900 border border-slate-800 p-2 text-xs text-slate-300 rounded">
                {formData.strength || 'N/A'}
              </div>
            </FieldWrapper>

            <FieldWrapper label="Batch Number" isChanged={isFieldChanged('batchNumber')} isRequiredHighlight={!formData.batchNumber}>
              <div className="bg-blue-900/20 border border-blue-500/50 p-2 text-xs font-mono text-blue-100 font-bold rounded ring-1 ring-blue-500/30">
                {formData.batchNumber || 'N/A'}
              </div>
            </FieldWrapper>

            <FieldWrapper label="Expiry Date" isChanged={isFieldChanged('expiryDate')}>
              <div className="bg-slate-900 border border-slate-800 p-2 text-xs font-mono text-slate-300 rounded">
                {formData.expiryDate || 'N/A'}
              </div>
            </FieldWrapper>

            <FieldWrapper label="Affected Quantity" isChanged={isFieldChanged('quantity')}>
              <div className="flex gap-1.5">
                <div className="bg-blue-900/20 border border-blue-500/50 p-2 text-xs font-mono text-blue-100 font-bold rounded flex-1">
                  {formData.quantity !== null && formData.quantity !== undefined ? formData.quantity : '0'}
                </div>
                <div className="bg-slate-900 border border-slate-800 p-2 text-xs text-slate-400 rounded">
                  {formData.unit || 'Units'}
                </div>
              </div>
            </FieldWrapper>
          </div>
        </div>

        {/* SECTION 3: Defect & Manufacturing Traceability */}
        <div className="space-y-2">
          <div className="border-b border-slate-800 pb-1 mt-2">
            <h3 className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">Defect Classification & Investigation</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <FieldWrapper label="Defect Category" isChanged={isFieldChanged('defectCategory')}>
              <div className="bg-slate-900 border border-slate-800 p-2 text-xs text-slate-300 rounded">
                {formData.defectCategory || 'N/A'}
              </div>
            </FieldWrapper>

            <FieldWrapper label="Complaint Category" isChanged={isFieldChanged('complaintCategory')}>
              <div className="bg-slate-900 border border-slate-800 p-2 text-xs text-slate-300 rounded">
                {formData.complaintCategory || 'N/A'}
              </div>
            </FieldWrapper>

            <div className="sm:col-span-2">
              <FieldWrapper label="Defect Description" isChanged={isFieldChanged('defectDescription')}>
                <div className="bg-slate-900 border border-slate-800 p-3 text-xs text-slate-300 rounded leading-relaxed">
                  {formData.defectDescription || 'No defect description extracted.'}
                </div>
              </FieldWrapper>
            </div>

            <div className="sm:col-span-2">
              <FieldWrapper label="Customer Remarks & Instructions" isChanged={isFieldChanged('customerRemarks')}>
                <div className="bg-slate-900 border border-slate-800 p-2.5 text-xs text-slate-300 rounded italic">
                  {formData.customerRemarks || 'No additional remarks.'}
                </div>
              </FieldWrapper>
            </div>
          </div>
        </div>

        {/* SECTION 4: Plant & Supplier Traceability */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-slate-800 text-[11px]">
          <div>
            <span className="text-[9px] text-slate-500 uppercase font-bold block">Plant:</span>
            <span className="text-slate-300">{formData.plant || 'Main Facility'}</span>
          </div>
          <div>
            <span className="text-[9px] text-slate-500 uppercase font-bold block">Mfg Site:</span>
            <span className="text-slate-300">{formData.mfgSite || 'Site Alpha'}</span>
          </div>
          <div>
            <span className="text-[9px] text-slate-500 uppercase font-bold block">Lot #:</span>
            <span className="text-slate-300 font-mono">{formData.lotNumber || 'N/A'}</span>
          </div>
          <div>
            <span className="text-[9px] text-slate-500 uppercase font-bold block">Supplier:</span>
            <span className="text-slate-300 truncate block">{formData.supplier || 'N/A'}</span>
          </div>
        </div>

        {/* SECTION 5: Evidence & Attachments */}
        {formData.attachments && formData.attachments.length > 0 && (
          <div className="pt-2 border-t border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
              Attached Files ({formData.attachments.length}):
            </span>
            <div className="flex flex-wrap gap-2">
              {formData.attachments.map((att) => (
                <div
                  key={att.id}
                  className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-900 border border-slate-800 rounded text-xs text-slate-300"
                >
                  <FileText className="h-3.5 w-3.5 text-blue-400" />
                  <span className="truncate max-w-[150px]">{att.name}</span>
                  <span className="text-[9px] text-emerald-400 font-mono">({att.size})</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

interface FieldWrapperProps {
  label: string;
  children: React.ReactNode;
  isChanged?: boolean;
  isRequiredHighlight?: boolean;
}

const FieldWrapper: React.FC<FieldWrapperProps> = ({
  label,
  children,
  isChanged = false,
  isRequiredHighlight = false,
}) => {
  return (
    <div className={`space-y-1 relative transition-all rounded-lg p-0.5 ${isChanged ? 'ring-2 ring-indigo-500 ring-offset-2 ring-offset-slate-900 bg-indigo-50/20 dark:bg-indigo-950/30' : ''}`}>
      <div className="flex items-center justify-between">
        <label className={`text-[11px] font-semibold flex items-center gap-1 ${isRequiredHighlight ? 'text-rose-500 dark:text-rose-400' : 'text-slate-600 dark:text-slate-400'}`}>
          {label}
          {isRequiredHighlight && <span className="text-rose-500">*</span>}
        </label>
        {isChanged && (
          <span className="text-[9px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-500/20 px-1.5 py-0.2 rounded uppercase tracking-wider animate-pulse">
            AI Edited
          </span>
        )}
      </div>
      {children}
    </div>
  );
};
