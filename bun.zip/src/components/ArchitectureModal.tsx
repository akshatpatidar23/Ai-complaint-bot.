import React from 'react';
import { X, FileText, Cpu, Database, Bot, Zap, Shield, CheckCircle } from 'lucide-react';

interface ArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ArchitectureModal: React.FC<ArchitectureModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-4xl w-full overflow-hidden shadow-2xl flex flex-col h-[85vh]">
        {/* Modal Header */}
        <div className="bg-slate-900 text-slate-100 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl border border-amber-500/30">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                Architecture & REST API Documentation
              </h3>
              <p className="text-xs text-slate-400">
                AI Complaint Copilot System Architecture, AI Tools & Database Models
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-xs text-slate-800 dark:text-slate-200">
          {/* Section 1: Core System Flow */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-2 uppercase tracking-wider">
              <Cpu className="h-4 w-4" /> 1. AI Copilot Architecture & Tools Overview
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/80 space-y-1.5">
                <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5 text-xs">
                  <Zap className="h-4 w-4 text-amber-500" /> Tool 1: Log Complaint
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Extracts natural language complaint emails/chats, normalizes entities (dates, batch numbers, dosage, quantities), and populates every structured output field automatically.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/80 space-y-1.5">
                <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5 text-xs">
                  <Bot className="h-4 w-4 text-indigo-500" /> Tool 2: Edit Complaint
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Understands natural language corrections (e.g. <em>"Sorry batch number is BMX24602"</em>), modifies ONLY specified fields, preserves state, recalculates risk, and highlights diffs.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/80 space-y-1.5">
                <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5 text-xs">
                  <FileText className="h-4 w-4 text-sky-500" /> Tool 3: Doc OCR Extraction
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Processes uploaded PDF, DOCX, TXT, Email (.eml), or PNG/JPG inspection photos via Gemini multimodal vision for instant form population and risk scoring.
                </p>
              </div>
            </div>
          </div>

          {/* Section 2: AI Risk Assessment Engine */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-2 uppercase tracking-wider">
              <Shield className="h-4 w-4" /> 2. AI Risk Assessment & cGMP Compliance Engine
            </h4>
            <div className="p-4 bg-slate-950 text-slate-200 rounded-xl border border-slate-800 space-y-2">
              <p className="text-xs leading-relaxed">
                After every complaint or edit turn, the system invokes Gemini 3.6 Flash configured with structured JSON schema to evaluate:
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px] font-mono text-indigo-300">
                <div className="p-2 bg-slate-900 rounded border border-slate-800">• Severity (Critical/Major/Minor)</div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">• Patient & Quality Risk</div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">• CAPA & Recall Advisory</div>
                <div className="p-2 bg-slate-900 rounded border border-slate-800">• FDA 15-Day FAR Criteria</div>
              </div>
            </div>
          </div>

          {/* Section 3: REST API Specifications */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-2 uppercase tracking-wider">
              <Database className="h-4 w-4" /> 3. REST API Endpoints Specification
            </h4>

            <div className="space-y-2 font-mono text-[11px]">
              <div className="p-3 bg-slate-100 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-2">
                <div>
                  <span className="px-2 py-0.5 bg-emerald-600 text-white rounded font-bold text-[10px] mr-2">POST</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100">/api/copilot/chat</span>
                </div>
                <span className="text-slate-500 text-[10px]">Natural language input, entity extraction, state edit & risk scoring</span>
              </div>

              <div className="p-3 bg-slate-100 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-2">
                <div>
                  <span className="px-2 py-0.5 bg-emerald-600 text-white rounded font-bold text-[10px] mr-2">POST</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100">/api/copilot/extract-document</span>
                </div>
                <span className="text-slate-500 text-[10px]">Multipart file upload (PDF/DOCX/TXT/Email/Images) with Gemini OCR</span>
              </div>

              <div className="p-3 bg-slate-100 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-2">
                <div>
                  <span className="px-2 py-0.5 bg-blue-600 text-white rounded font-bold text-[10px] mr-2">GET</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100">/api/complaints</span>
                </div>
                <span className="text-slate-500 text-[10px]">List complaints with search query, priority & status filtering</span>
              </div>

              <div className="p-3 bg-slate-100 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-2">
                <div>
                  <span className="px-2 py-0.5 bg-purple-600 text-white rounded font-bold text-[10px] mr-2">GET</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100">/api/system/schema</span>
                </div>
                <span className="text-slate-500 text-[10px]">Returns live relational database tables & audit trail</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 dark:bg-slate-950 px-6 py-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-xs transition-colors"
          >
            Close Documentation
          </button>
        </div>
      </div>
    </div>
  );
};
