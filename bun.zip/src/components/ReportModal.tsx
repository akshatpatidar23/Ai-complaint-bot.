import React from 'react';
import { X, Printer, Shield, CheckCircle2, FileText, AlertTriangle, Building2, Calendar, Hash } from 'lucide-react';
import { ComplaintData, RiskAssessment } from '../types/complaint';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  complaint: ComplaintData;
  risk?: RiskAssessment;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  complaint,
  risk,
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in print:p-0 print:bg-white print:static">
      <div className="bg-white text-slate-900 border border-slate-200 rounded-2xl max-w-4xl w-full overflow-hidden shadow-2xl flex flex-col h-[90vh] print:h-auto print:max-h-none print:shadow-none print:border-none print:rounded-none">
        {/* Modal Header - Hidden on Print */}
        <div className="bg-slate-900 text-slate-100 px-6 py-4 border-b border-slate-800 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/30">
              <Printer className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                cGMP Product Complaint Investigation Report
              </h3>
              <p className="text-xs text-slate-400">
                Official Regulatory Summary Record for {complaint.complaintId || 'CMP-RECORD'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              id="btn-print-report"
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Printer className="h-3.5 w-3.5" /> Print / Save PDF
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-8 overflow-y-auto flex-1 space-y-6 text-xs text-slate-800 font-sans print:p-6 print:overflow-visible">
          {/* Letterhead Header */}
          <div className="border-b-2 border-slate-900 pb-4 flex items-start justify-between">
            <div>
              <div className="text-xl font-extrabold text-slate-900 uppercase tracking-tight">
                PHARMACO GLOBAL QUALITY ASSURANCE
              </div>
              <div className="text-xs text-slate-600 font-medium">
                cGMP Quality Control & Incident Regulatory Reporting Division
              </div>
              <div className="text-[10px] text-slate-500">
                Compliance Standard: FDA 21 CFR 211.198 / EU GMP Vol 4 Chapter 8
              </div>
            </div>

            <div className="text-right border-l-2 border-slate-300 pl-4">
              <div className="text-xs font-bold text-slate-500 uppercase">Document Ref</div>
              <div className="text-lg font-mono font-extrabold text-indigo-700">
                {complaint.complaintId || 'CMP-2026-0891'}
              </div>
              <div className="text-[11px] text-slate-500">
                Generated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
              </div>
            </div>
          </div>

          {/* Report Metadata Banner */}
          <div className="bg-slate-100 p-4 rounded-xl border border-slate-300 grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <div className="text-[10px] font-bold text-slate-500 uppercase">Customer Name</div>
              <div className="font-bold text-slate-900 text-xs">{complaint.customerName || 'N/A'}</div>
            </div>
            <div>
              <div className="text-[10px] font-bold text-slate-500 uppercase">Incident Date</div>
              <div className="font-semibold text-slate-800 text-xs">{complaint.complaintDate || 'N/A'}</div>
            </div>
            <div>
              <div className="text-[10px] font-bold text-slate-500 uppercase">Priority Rating</div>
              <div className="font-bold text-rose-700 text-xs uppercase">{complaint.priority || 'Medium'}</div>
            </div>
            <div>
              <div className="text-[10px] font-bold text-slate-500 uppercase">Record Status</div>
              <div className="font-bold text-indigo-700 text-xs uppercase">{complaint.status || 'Draft'}</div>
            </div>
          </div>

          {/* Product & Batch Traceability Table */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-1">
              1. Product Identification & Batch Traceability
            </h4>

            <table className="w-full text-left border-collapse border border-slate-300">
              <tbody>
                <tr className="border-b border-slate-300 bg-slate-50">
                  <td className="p-2.5 font-bold w-1/4 border-r border-slate-300">Product Name</td>
                  <td className="p-2.5 font-semibold text-indigo-900 w-1/4 border-r border-slate-300">{complaint.productName || 'N/A'}</td>
                  <td className="p-2.5 font-bold w-1/4 border-r border-slate-300">Dosage Form & Strength</td>
                  <td className="p-2.5 font-semibold w-1/4">{complaint.dosageForm || 'N/A'} ({complaint.strength || 'N/A'})</td>
                </tr>
                <tr className="border-b border-slate-300">
                  <td className="p-2.5 font-bold border-r border-slate-300">Batch Number</td>
                  <td className="p-2.5 font-mono font-bold text-indigo-700 border-r border-slate-300">{complaint.batchNumber || 'N/A'}</td>
                  <td className="p-2.5 font-bold border-r border-slate-300">Lot Number</td>
                  <td className="p-2.5 font-mono">{complaint.lotNumber || 'N/A'}</td>
                </tr>
                <tr className="border-b border-slate-300 bg-slate-50">
                  <td className="p-2.5 font-bold border-r border-slate-300">Manufacturing Date</td>
                  <td className="p-2.5 border-r border-slate-300">{complaint.mfgDate || 'N/A'}</td>
                  <td className="p-2.5 font-bold border-r border-slate-300">Expiration Date</td>
                  <td className="p-2.5 font-semibold text-rose-700">{complaint.expiryDate || 'N/A'}</td>
                </tr>
                <tr>
                  <td className="p-2.5 font-bold border-r border-slate-300">Pack Size & Quantity</td>
                  <td className="p-2.5 border-r border-slate-300">{complaint.packSize || 'N/A'} ({complaint.quantity ? `${complaint.quantity} ${complaint.unit}` : 'N/A'})</td>
                  <td className="p-2.5 font-bold border-r border-slate-300">Mfg Plant & Site</td>
                  <td className="p-2.5">{complaint.plant || 'N/A'} / {complaint.mfgSite || 'N/A'}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Defect Analysis */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-1">
              2. Customer Reported Defect Details
            </h4>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-300 space-y-1">
              <div className="flex justify-between text-[11px] font-bold text-slate-700 border-b border-slate-200 pb-1">
                <span>Defect Category: {complaint.defectCategory || 'Physical Defect'}</span>
                <span>Complaint Classification: {complaint.complaintCategory || 'Quality Defect'}</span>
              </div>
              <p className="text-xs text-slate-800 leading-relaxed pt-1">
                {complaint.defectDescription || 'No defect description recorded.'}
              </p>
            </div>
          </div>

          {/* AI Risk Assessment & Regulatory Section */}
          {risk && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-1">
                3. AI Automated Quality Risk Assessment & CAPA Recommendations
              </h4>

              <div className="border border-slate-300 rounded-lg p-3 space-y-2 bg-slate-50">
                <div className="flex justify-between items-center text-xs font-bold border-b border-slate-200 pb-2">
                  <span>Severity: <strong className="text-rose-700">{risk.severity}</strong></span>
                  <span>Risk Rating: <strong className="text-amber-700">{risk.riskLevel}</strong></span>
                  <span>AI Confidence: <strong className="text-indigo-700">{risk.confidenceScore}%</strong></span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div><strong>Patient Risk:</strong> {risk.patientRisk}</div>
                  <div><strong>Compliance Risk:</strong> {risk.complianceRisk}</div>
                  <div><strong>Quality Impact:</strong> {risk.qualityRisk}</div>
                  <div><strong>Business Impact:</strong> {risk.businessRisk}</div>
                </div>

                <div className="pt-2 border-t border-slate-200">
                  <div className="font-bold text-indigo-900">Scientific Root Cause Hypothesis:</div>
                  <p className="text-xs text-slate-800 italic font-mono">{risk.rootCauseHypothesis}</p>
                </div>

                <div className="pt-2 border-t border-slate-200 grid grid-cols-2 gap-2 text-[11px]">
                  <div><strong>CAPA Action:</strong> {risk.capaRecommendation}</div>
                  <div><strong>Regulatory Guidance:</strong> {risk.regulatoryReportingRecommendation}</div>
                </div>
              </div>
            </div>
          )}

          {/* Signature Sign-Off Footer */}
          <div className="pt-8 border-t-2 border-slate-900 grid grid-cols-2 gap-8 text-xs font-semibold">
            <div className="space-y-8">
              <div className="border-b border-slate-400 pb-1 text-slate-500">
                Prepared by QA Lead / AI Copilot Validation Engine
              </div>
              <div className="text-[10px] text-slate-400">Signature & Date</div>
            </div>

            <div className="space-y-8">
              <div className="border-b border-slate-400 pb-1 text-slate-500">
                Approved by Quality Assurance Director / Qualified Person (QP)
              </div>
              <div className="text-[10px] text-slate-400">Signature & Date</div>
            </div>
          </div>
        </div>

        {/* Footer Buttons - Hidden on Print */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex justify-end print:hidden">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl text-xs transition-colors"
          >
            Close Report
          </button>
        </div>
      </div>
    </div>
  );
};
