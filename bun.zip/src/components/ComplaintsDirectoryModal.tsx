import React, { useState, useEffect } from 'react';
import { X, FolderOpen, Search, Filter, Calendar, Hash, ArrowUpRight, Clock, Shield } from 'lucide-react';
import { ComplaintData } from '../types/complaint';

interface ComplaintsDirectoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectComplaint: (complaint: ComplaintData) => void;
  activeId?: string;
}

export const ComplaintsDirectoryModal: React.FC<ComplaintsDirectoryModalProps> = ({
  isOpen,
  onClose,
  onSelectComplaint,
  activeId,
}) => {
  const [complaints, setComplaints] = useState<ComplaintData[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPriority, setFilterPriority] = useState('ALL');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchComplaints();
    }
  }, [isOpen]);

  const fetchComplaints = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/complaints');
      const data = await res.json();
      setComplaints(data.complaints || []);
    } catch (err) {
      console.error('Failed to load complaints directory:', err);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  const filtered = complaints.filter((c) => {
    const matchesSearch =
      c.complaintId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.batchNumber.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesPriority = filterPriority === 'ALL' || c.priority === filterPriority;

    return matchesSearch && matchesPriority;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-4xl w-full overflow-hidden shadow-2xl flex flex-col h-[85vh]">
        {/* Modal Header */}
        <div className="bg-slate-900 text-slate-100 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-sky-500/20 text-sky-400 rounded-xl border border-sky-500/30">
              <FolderOpen className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                Logged Complaints Directory
              </h3>
              <p className="text-xs text-slate-400">
                Browse, search, and load customer quality complaint records
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="h-4 w-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by ID, customer name, product, or batch number..."
              className="w-full bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
              <Filter className="h-3.5 w-3.5" /> Priority:
            </span>
            {['ALL', 'Critical', 'High', 'Medium'].map((p) => (
              <button
                key={p}
                onClick={() => setFilterPriority(p)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  filterPriority === p
                    ? 'bg-sky-600 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 hover:bg-slate-100'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* Directory List */}
        <div className="p-5 overflow-y-auto flex-1 space-y-3 text-xs">
          {isLoading ? (
            <div className="text-center py-12 text-slate-400">Loading complaints...</div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              No matching complaint records found.
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  onSelectComplaint(item);
                  onClose();
                }}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                  activeId === item.id || activeId === item.complaintId
                    ? 'bg-sky-50/50 dark:bg-sky-950/40 border-sky-400 dark:border-sky-700 ring-2 ring-sky-500/20'
                    : 'bg-white dark:bg-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-800 border-slate-200 dark:border-slate-700/80 shadow-sm'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono font-extrabold text-indigo-600 dark:text-indigo-400 text-sm">
                      {item.complaintId}
                    </span>
                    <span className="font-bold text-slate-900 dark:text-slate-100 text-xs">
                      {item.customerName}
                    </span>
                    <span className="text-slate-400">•</span>
                    <span className="text-slate-600 dark:text-slate-300 font-medium">
                      {item.productName} ({item.strength})
                    </span>
                  </div>

                  <p className="text-slate-500 dark:text-slate-400 text-xs line-clamp-1">
                    {item.defectDescription}
                  </p>

                  <div className="flex items-center gap-4 text-[11px] text-slate-400 pt-1">
                    <span>
                      Batch: <strong className="font-mono text-slate-300">{item.batchNumber || 'N/A'}</strong>
                    </span>
                    <span>
                      Qty: <strong>{item.quantity ? `${item.quantity} ${item.unit}` : 'Unspecified'}</strong>
                    </span>
                    <span>Date: {item.complaintDate}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span
                    className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                      item.priority === 'Critical'
                        ? 'bg-rose-500/10 text-rose-600 border-rose-500/30'
                        : item.priority === 'High'
                        ? 'bg-amber-500/10 text-amber-600 border-amber-500/30'
                        : 'bg-blue-500/10 text-blue-600 border-blue-500/30'
                    }`}
                  >
                    {item.priority}
                  </span>

                  <button className="p-2 text-sky-600 dark:text-sky-400 hover:bg-sky-50 dark:hover:bg-sky-950/80 rounded-lg transition-colors flex items-center gap-1 font-semibold text-xs">
                    <span>Load Form</span>
                    <ArrowUpRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 dark:bg-slate-950 px-6 py-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl text-xs transition-colors"
          >
            Close Directory
          </button>
        </div>
      </div>
    </div>
  );
};
