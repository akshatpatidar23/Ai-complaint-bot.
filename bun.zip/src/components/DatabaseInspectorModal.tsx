import React, { useState, useEffect } from 'react';
import { X, Database, Table, RefreshCw, CheckCircle2, ShieldCheck, Code2 } from 'lucide-react';

interface DatabaseInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DatabaseInspectorModal: React.FC<DatabaseInspectorModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [schemaData, setSchemaData] = useState<any>(null);
  const [activeTable, setActiveTable] = useState<string>('complaints');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      fetchSchema();
    }
  }, [isOpen]);

  const fetchSchema = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/system/schema');
      const data = await res.json();
      setSchemaData(data.schemaDump);
    } catch (err) {
      console.error('Failed to fetch DB schema:', err);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  const tables = [
    { key: 'users', label: 'Users', icon: '👤' },
    { key: 'complaints', label: 'Complaints', icon: '📋' },
    { key: 'complaintHistory', label: 'Complaint History', icon: '📜' },
    { key: 'comments', label: 'Comments', icon: '💬' },
    { key: 'attachments', label: 'Attachments', icon: '📎' },
    { key: 'auditLogs', label: 'Audit Logs', icon: '🛡️' },
    { key: 'riskAssessments', label: 'Risk Assessment', icon: '⚡' },
    { key: 'notifications', label: 'Notifications', icon: '🔔' },
  ];

  const currentTableRecords = schemaData ? schemaData[activeTable] || [] : [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-5xl w-full overflow-hidden shadow-2xl flex flex-col h-[85vh]">
        {/* Modal Header */}
        <div className="bg-slate-900 text-slate-100 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-purple-500/20 text-purple-400 rounded-xl border border-purple-500/30">
              <Database className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                Normalized Database Inspector
              </h3>
              <p className="text-xs text-slate-400">
                Live relational database tables, foreign keys, and audit logs
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchSchema}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              title="Refresh Schema Data"
            >
              <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar Table Selector */}
          <div className="w-56 bg-slate-50 dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 p-3 space-y-1 overflow-y-auto shrink-0">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 mb-2">
              Relational Tables
            </div>
            {tables.map((t) => (
              <button
                key={t.key}
                onClick={() => setActiveTable(t.key)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                  activeTable === t.key
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800'
                }`}
              >
                <span className="flex items-center gap-2">
                  <span>{t.icon}</span>
                  <span>{t.label}</span>
                </span>
                <span className="text-[10px] px-1.5 py-0.2 bg-black/20 rounded-full font-mono">
                  {schemaData ? (schemaData[t.key] || []).length : 0}
                </span>
              </button>
            ))}
          </div>

          {/* Main Table View */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4 text-xs bg-slate-900 text-slate-100">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Table className="h-4 w-4 text-purple-400" />
                Table: <span className="text-purple-300 font-mono">{activeTable}</span>
              </h4>
              <span className="text-xs text-slate-400">
                Total Records: <strong className="text-indigo-400">{currentTableRecords.length}</strong>
              </span>
            </div>

            {isLoading ? (
              <div className="flex items-center justify-center py-12 text-slate-400">
                <RefreshCw className="h-6 w-6 animate-spin text-purple-400 mr-2" />
                Loading Database State...
              </div>
            ) : currentTableRecords.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                No records found in table <code className="font-mono">{activeTable}</code>.
              </div>
            ) : (
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 overflow-x-auto shadow-inner">
                <pre className="text-[11px] font-mono text-emerald-400 leading-relaxed">
                  {JSON.stringify(currentTableRecords, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-950 px-6 py-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-emerald-400" />
            <span>Normalized Relational Storage • Full Transaction Audit Logs</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl text-xs transition-colors"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
