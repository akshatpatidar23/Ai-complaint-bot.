import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Bot,
  User,
  Paperclip,
  Sparkles,
  RefreshCw,
  HelpCircle,
  FileText,
  AlertCircle,
  CheckCircle2,
  ArrowRight,
  MessageSquare,
  History,
  Upload,
  Zap,
} from 'lucide-react';
import { ChatMessage, ComplaintData } from '../types/complaint';
import { RiskAssessmentCard } from './RiskAssessmentCard';

interface CopilotChatPanelProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => Promise<void>;
  onFileUpload: (file: File) => Promise<void>;
  isLoading: boolean;
  currentFormState: ComplaintData;
  onOpenDiffModal: () => void;
}

const PRESET_PROMPTS = [
  {
    label: '💊 Discolored Amoxicillin Capsules',
    text: 'Apollo Pharmacy reported discolored capsules in Amoxicillin Capsules 500 mg, batch BMX24602, expiry 2027-11, affected quantity 48 capsules.',
  },
  {
    label: '✏️ Edit Batch & Quantity',
    text: 'Sorry batch number is BMX24602 and affected quantity is 48 capsules.',
  },
  {
    label: '🧪 Broken Injection Seals',
    text: 'MediCare Regional Hospital reported loose rubber stoppers and broken flip-off seals on 4 vials of Ceftriaxone 1g Injections, batch CFX99104.',
  },
  {
    label: '📦 Wrong Expiry Date Printed',
    text: 'PharmaPlus retail chain reported incorrect expiry date printed on Paracetamol 650mg tablets packaging, lot L-8812.',
  },
];

export const CopilotChatPanel: React.FC<CopilotChatPanelProps> = ({
  messages,
  onSendMessage,
  onFileUpload,
  isLoading,
  currentFormState,
  onOpenDiffModal,
}) => {
  const [inputText, setInputText] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!inputText.trim() || isLoading) return;
    const text = inputText;
    setInputText('');
    await onSendMessage(text);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploading(true);
    try {
      await onFileUpload(file);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-xl shadow-lg overflow-hidden flex flex-col h-full">
      {/* Chat Header */}
      <div className="bg-slate-900/80 text-slate-100 px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className="p-1.5 bg-blue-600/30 text-blue-400 rounded-lg border border-blue-500/40">
              <Bot className="h-4 w-4" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full bg-emerald-400 ring-2 ring-slate-900 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-black uppercase tracking-widest text-slate-200">
                AI Copilot Chat Assistant
              </h3>
              <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                Active
              </span>
            </div>
          </div>
        </div>

        <button
          onClick={() => fileInputRef.current?.click()}
          id="btn-upload-doc-header"
          className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors"
          title="Upload PDF, DOCX, TXT, Email, or Images for OCR extraction"
        >
          <Upload className="h-3.5 w-3.5 text-sky-400" />
          <span className="hidden sm:inline">Upload Doc / Email</span>
        </button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept=".pdf,.docx,.doc,.txt,.eml,.png,.jpg,.jpeg,.tiff"
          className="hidden"
        />
      </div>

      {/* Suggested Prompts Presets Banner */}
      <div className="bg-slate-900/40 p-2 px-3 border-b border-slate-800 shrink-0">
        <div className="text-[9px] font-bold uppercase tracking-wider text-slate-400 mb-1.5 flex items-center gap-1">
          <Sparkles className="h-3 w-3 text-blue-400" />
          Quick Actions & Prompts:
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 scrollbar-none">
          {PRESET_PROMPTS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => onSendMessage(p.text)}
              disabled={isLoading}
              className="text-[10px] whitespace-nowrap px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-all font-bold shrink-0 disabled:opacity-50"
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Conversation Thread */}
      <div className="p-3 overflow-y-auto space-y-3 flex-1 text-xs">
        {messages.length === 0 ? (
          <div className="text-center py-10 px-4 space-y-2">
            <div className="inline-flex p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <MessageSquare className="h-6 w-6" />
            </div>
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              AI Copilot Ready
            </h4>
            <p className="text-[11px] text-slate-400 max-w-xs mx-auto leading-relaxed">
              Describe a complaint in natural language, upload an inspection document, or type e.g., <em>"Batch is BMX24602 and quantity is 48"</em>.
            </p>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'assistant' && (
                <div className="h-6 w-6 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                  <Bot className="h-3.5 w-3.5" />
                </div>
              )}

              <div
                className={`max-w-[88%] rounded-xl p-3 shadow-sm space-y-1.5 ${
                  msg.sender === 'user'
                    ? 'bg-blue-600 text-white rounded-br-none font-medium'
                    : 'bg-slate-900 text-slate-100 border border-slate-800 rounded-bl-none'
                }`}
              >
                {/* Sender Title */}
                <div className="flex items-center justify-between text-[9px] opacity-70 border-b border-black/10 dark:border-white/10 pb-0.5 mb-0.5 font-bold uppercase tracking-wider">
                  <span>{msg.sender === 'user' ? 'You' : 'AI Copilot'}</span>
                  <span>{msg.timestamp}</span>
                </div>

                {/* Message Text */}
                <p className="whitespace-pre-wrap leading-relaxed text-xs">
                  {msg.text}
                </p>

                {/* Document Attached Tag */}
                {msg.isDocumentExtract && (
                  <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-sky-500/10 text-sky-300 border border-sky-500/20 text-[10px] font-semibold">
                    <FileText className="h-3 w-3" /> Processed: {msg.fileName}
                  </div>
                )}

                {/* Changed Fields Diffs Tag */}
                {msg.diffs && msg.diffs.length > 0 && (
                  <div className="bg-blue-950/50 border border-blue-500/30 p-2 rounded-lg space-y-1 my-1">
                    <div className="text-[9px] font-bold text-blue-400 uppercase tracking-wider flex items-center justify-between">
                      <span>Fields Auto-Updated ({msg.diffs.length})</span>
                      <button
                        onClick={onOpenDiffModal}
                        className="underline hover:text-blue-300"
                      >
                        Diff View
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {msg.diffs.map((d, i) => (
                        <span
                          key={i}
                          className="px-1.5 py-0.5 rounded bg-blue-900/40 text-blue-200 text-[9px] font-mono"
                        >
                          {d.label}: <s>{String(d.oldValue)}</s> → <strong>{String(d.newValue)}</strong>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Missing Fields Clarification Request */}
                {msg.missingFields && msg.missingFields.length > 0 && (
                  <div className="bg-rose-950/40 border border-rose-500/30 p-2 rounded-lg space-y-0.5 text-rose-300">
                    <div className="font-bold text-[10px] flex items-center gap-1 uppercase tracking-wider">
                      <AlertCircle className="h-3 w-3 text-rose-400" />
                      Missing Mandatory Information:
                    </div>
                    <ul className="list-disc list-inside text-[10px] space-y-0.5">
                      {msg.missingFields.map((f, idx) => (
                        <li key={idx}>{f}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Embedded Risk Assessment Card */}
                {msg.riskAssessment && (
                  <RiskAssessmentCard risk={msg.riskAssessment} />
                )}
              </div>

              {msg.sender === 'user' && (
                <div className="h-6 w-6 rounded-lg bg-slate-800 text-slate-300 flex items-center justify-center shrink-0 mt-0.5 border border-slate-700">
                  <User className="h-3.5 w-3.5" />
                </div>
              )}
            </div>
          ))
        )}

        {/* Loading Spinner */}
        {(isLoading || isUploading) && (
          <div className="flex gap-2 justify-start items-center text-slate-400 text-xs">
            <div className="h-6 w-6 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
              <Bot className="h-3.5 w-3.5 animate-spin" />
            </div>
            <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 flex items-center gap-2">
              <RefreshCw className="h-3.5 w-3.5 animate-spin text-blue-400" />
              <span className="text-[11px]">
                {isUploading
                  ? 'Running document OCR & entity extraction...'
                  : 'Analyzing complaint context & evaluating risk...'}
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-2.5 bg-slate-900 border-t border-slate-800 space-y-1.5 shrink-0">
        <div className="relative">
          <textarea
            rows={2}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isLoading || isUploading}
            placeholder="Type complaint narrative, update request (e.g. 'Batch is BMX24602'), or questions..."
            className="w-full bg-slate-950 text-slate-100 text-xs p-2.5 pr-20 rounded-lg border border-slate-700 focus:outline-none focus:border-blue-500 resize-none shadow-inner"
          />

          <div className="absolute right-2 bottom-2 flex items-center gap-1">
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isLoading || isUploading}
              id="btn-upload-doc-input"
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
              title="Upload file (PDF, DOCX, TXT, Email, Images)"
            >
              <Paperclip className="h-3.5 w-3.5" />
            </button>

            <button
              onClick={handleSend}
              disabled={!inputText.trim() || isLoading || isUploading}
              id="btn-send-message"
              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 text-white font-bold rounded text-xs transition-all flex items-center gap-1 shadow-sm"
            >
              <span>Send</span>
              <Send className="h-3 w-3" />
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between text-[9px] text-slate-500 px-1">
          <span>Enter to send, Shift+Enter for newline</span>
          <span className="flex items-center gap-1 text-blue-400 font-semibold">
            <Zap className="h-2.5 w-2.5" /> Auto-Extracting Entities to Form
          </span>
        </div>
      </div>
    </div>
  );
};
